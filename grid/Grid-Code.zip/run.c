#include<avr/io.h>
#include<util/delay.h>
#include<avr/interrupt.h>
#include<avr/pgmspace.h>

#define uchar unsigned char

volatile unsigned char rxd,rxbuf[20],len=0,ptr=0,errorflag=0,rec[2];
#include "algo.h"
#include "move.h"

void tx(unsigned char);
void string(char *);



void tx(unsigned char data)
{
UDR=data;
while(!(UCSRA&(1<<UDRE))); //wait till Data buffer is not empty
}


 
 
 
// 6  5  4  3  2  1
// 0  1  2  3  4  5

//black-0
//white -1
//center    
// 6  5  4  3  2  1
// 0  1  2  3  4  5
// 0  0  1  1  0  0
// 0  1  1  0  0  0
// 0  0  0  1  1  0
 
 
 

 

void string(char *point)   //Function to transmitt continuous data string
{
while(*point!='\0')
{
tx(*point);
_delay_ms(1);
point++;
}
}

void checksum(void)
{
 int i,total;
 unsigned char c,d,e;
 total=0;
 for(i=0;i<len;i++)
 {
  total=total+rxbuf[i];
 }
 total=total&0xFF;
 c=total%10;
 total=total/10;
 d=total%10;
 total=total/10;
 e=total%10;
 tx('0'+e);_delay_ms(10);
 tx('0'+d);_delay_ms(10);
 tx('0'+c);_delay_ms(10);
// robostart();
}


ISR(USART_RXC_vect)   // UART receiver interrupt service ruotine
{
rxd=UDR;
if(errorflag==1)
{
  rec[ptr]=rxd;
  ptr++;
 if(ptr==2)
 {
  if(rec[0]==0x02 && rec[1]==0x01)
  {string("ok");
   storedissect();
   algorun();
   throwit();
  }
  if(rec[0]==0x02 && rec[1]==0x02)
  {string("Fail");
  }
   ptr=0;
   len=0;
   errorflag=0;
 }
}
else
{
 if(ptr==0)
 {
 len=rxd;
 rxbuf[ptr]=len;  
 }
 else
 {rxbuf[ptr]=rxd;
 }
  ptr=ptr+1;
  if(ptr==len)
 { 
  checksum();errorflag=1;
  ptr=0;
  }
}

}
void throwit()
{uchar i,a,b;
 for(i=0;i<pathptr;i++)
 {
  
    a=path[i]&0xf0;
	a=a>>4;
	b=path[i]&0x0f;
	tx('0'+ a);
	_delay_ms(100);
	tx('0'+ b);
	_delay_ms(100);
	tx(' ');
	_delay_ms(100);
 }
 return;
}

void storedissect()
{
 uchar i,j,ti,tj;
  ti=rxbuf[1]&0xf0; //start point
  ti=ti>>4;
  tj=rxbuf[1]&0x0f;
  arr[ti][tj]=3;

  for(j=0;j<rxbuf[2];j++) //check point storage
   {
    ti=rxbuf[2+j+1]&0xf0;
    ti=ti>>4;
    tj=rxbuf[2+j+1]&0x0f;
    arr[ti][tj]=2;
   }
   i=2+rxbuf[2]+1;
  for(j=0;j<rxbuf[i];j++) //danger point storage
   {
    ti=rxbuf[i+1+j]&0xf0;
    ti=ti>>4;
    tj=rxbuf[i+1+j]&0x0f;
    arr[ti][tj]=1;
   }
   return;
}
void robostop(void)
{
 PORTC=0x00;
}
void robostart(void)
{
 unsigned char zun=0,c,d;

 while(zun!=pathptr)
 { c=PINA&0x1E;
  d=PINA&0x21;
  if(c==0x0c && d!=0x21)
  {
   forw(8,2);
  }
  else if(c==0x06 && d!=0x21)
  {
   lforw(8,2);  
  }
  else if(c==0x18 && d!=0x21)
  {
   rforw(8,2);  
  }
  else if(c==0x0E && d!=0x21)
  {
    
   lforw(8,2);
  }
  else if(c==0x1C && d!=0x21)
  {
    
   rforw(8,2);
  }
  else if(d==0x21)
  {PORTC=0x00;
   _delay_ms(1000);
   while(d!=0x00)
   { d=PINA&0x21;
   forw(8,5);
   }
   tracepath(zun);
   zun++;
         
  }}
  c=PINA&0x1E;
  d=PINA&0x21;
  while(d!=0x21)
  {
  c=PINA&0x1E;
  d=PINA&0x21;
  if(c==0x0c && d!=0x21)
  {
   forw(8,2);
  }
  else if(c==0x06 && d!=0x21)
  {
   lforw(8,2);  
  }
  else if(c==0x18 && d!=0x21)
  {
   rforw(8,2);  
  }
  else if(c==0x0E && d!=0x21)
  {
    
   lforw(8,2);
  }
  else if(c==0x1C && d!=0x21)
  {
    
   rforw(8,2);
  }
  }
   robostop();
}
void uart_init(void)
{
UBRRH=0;
UBRRL=25;     //UART initialisation in inturrupt mode with baud rate of 38400 bps
UCSRB=0x98;
UCSRC=0x86;
}

int main(void)
{DDRA=0x00;
 PORTA=0xFF;
 DDRC=0xFF;
 PORTC=0x00;
 pos=1;
 uart_init();
 sei();
 //RF module initialisation
 tx('1');  // setting self adress as 1
 tx('2');  // setting remote adress  2
 tx('3');  // selecting channel as 3
 //_delay_ms(1000);
 //_delay_ms(1000);
 //algorun();
 //robostart();
// robostop();
 while(1)
 {
  
 }
 return 0;
 
}